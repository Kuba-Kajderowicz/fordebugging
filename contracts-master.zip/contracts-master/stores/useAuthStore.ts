import { defineStore } from "pinia";

type User = {
  id: number;
  name: string;
  email: string;
};

type Credentials = {
  email: string;
  password: string;
};

type Group = {
  name: string;
  level: string;
  minage: number;
  maxage: number;
};

type Count = {
  count: number;
};

export const useAuthStore = defineStore("auth", () => {
  const user = ref<User | null>(null);
  const group = ref<Group | null>(null);
  const count = ref<Count | null>(null);

  const isLoggedIn = computed(() => !!user.value);

  async function logout() {
    await useApiFetch("/logout", { method: "POST" });

    user.value = null;

    navigateTo("/login");
  }

  async function fetchUser() {
    const { data, error } = await useApiFetch("/api/user");
    user.value = data.value as User;
  }

  async function login(credentials: Credentials) {
    await useApiFetch("/sanctum/csrf-cookie");

    const login = await useApiFetch("/login", {
      method: "POST",
      body: credentials,
    });

    await fetchUser();

    return login;
  }

  async function createGroup(groupInfo: Group) {
    // Get Authenticated
    await useApiFetch("/sanctum/csrf-cookie");

    const newGroup = await useApiFetch("/api/group", {
      method: "POST",
      body: groupInfo,
    });

    return newGroup;
  }

  async function fetchGroups() {
    const { data, error } = await useApiFetch("/api/group");
    group.value = data.value as Group;
  }

  async function fetchGroupCount() {
    // Get Authenticated
    await useApiFetch("/sanctum/csrf-cookie");

    const count = await useApiFetch("/api/group/count");
    return count;
  }

  return {
    user,
    login,
    isLoggedIn,
    fetchUser,
    logout,
    createGroup,
    group,
    fetchGroups,
    fetchGroupCount,
  };
});
