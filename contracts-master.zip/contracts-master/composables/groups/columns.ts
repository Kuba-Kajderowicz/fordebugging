import type { ColumnDef } from "@tanstack/vue-table";
import DropdownAction from "../../components/ui/DataTableDropDown.vue";
import { Checkbox } from '@/components/ui/checkbox'

// This type is used to define the shape of our data.
// You can use a Zod schema here if you want.
export interface Group {
  id: string;
  name: string;
  level: string;
  category: string;
  minage: number;
  maxage: number;
}

export const columns: ColumnDef<Group>[] = [
  {
    id: 'select',
        header: ({ table }) => h(Checkbox, {
            'checked': table.getIsAllPageRowsSelected(),
            'onUpdate:checked': (value: boolean) => table.toggleAllPageRowsSelected(!!value),
            'ariaLabel': 'Select all',
        }),
        cell: ({ row }) => h(Checkbox, {
            'checked': row.getIsSelected(),
            'onUpdate:checked': (value: boolean) => row.toggleSelected(!!value),
            'ariaLabel': 'Select row',
        }),
        enableSorting: false,
        enableHiding: false,
  },
  {
    accessorKey: "name",
    header: "Name",
  },
  {
    accessorKey: "level",
    header: "Level",
  },
  {
    accessorKey: "category",
    header: "Category",
  },
  {
    accessorKey: "minage",
    header: "Minimum Age",
  },
  {
    accessorKey: "maxage",
    header: "Maximum Age",
  },
  {
    id: "actions",
    enableHiding: false,
    cell: ({ row }) => {
      const payment = row.original;

      return h(
        "div",
        { class: "relative" },
        h(DropdownAction, {
          payment,
        })
      );
    },
  },
];
