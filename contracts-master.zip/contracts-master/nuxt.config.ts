// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  devtools: { enabled: true },
  modules: [
    // ...
    "@pinia/nuxt",
    "@nuxtjs/tailwindcss",
    "nuxt-icon",
    "@vueuse/nuxt",
    "nuxt-headlessui",
    '@morev/vue-transitions/nuxt',
    'radix-vue/nuxt',
    'shadcn-nuxt',
    '@nuxtjs/eslint-module',
  ],
  tailwindcss: { exposeConfig: true },
  headlessui: { prefix: "H" },
  vueTransitions: {},
  shadcn: {
    /**
     * Prefix for all the imported component
     */
    prefix: '',
    /**
     * Directory that the component lives in.
     * @default "./components/ui"
     */
    componentDir: './components/ui'
  },
  app: {
    head: {
      title: "Kuba Contracts",
      link: [
        //favicon
        { rel: "icon", type: "image/x-icon", href: "/logo-icon.svg" },
        // inter font
        { rel: "stylesheet", href: "https://rsms.me/inter/inter.css" },
        { rel: "preconnect", href: "https://rsms.me/" },
      ],
    },
  },
});
