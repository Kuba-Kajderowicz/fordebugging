<script lang="ts" setup>
  const auth = useAuthStore();

  async function handleLogout() {
    await auth.logout();
  }
</script>

<template>
  <div>
    <!-- <button v-if="auth.isLoggedIn" @click="handleLogout()"> Logout </button> -->
<!--<pre> {{ auth.user }}</pre>-->
   
    <slot />
  </div>
</template>

<style scoped></style>
