<template>
  <div>
    <!-- Header -->
    <Header />
    <div class="container lg:grid lg:grid-cols-12 lg:gap-10">
      <!-- Sidebar -->
      <SideBar class="hidden lg:col-span-3 lg:block" />

      <!-- Main Section -->
      <main class="py-5 lg:col-span-8">

        <slot />

      </main>

    </div>
  </div>
</template>
