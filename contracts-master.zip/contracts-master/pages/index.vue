<script lang="ts" setup>


await navigateTo('/login')

  
</script>


<template>
  <div>
    Page: foo
  </div>
</template>

<style scoped></style>
