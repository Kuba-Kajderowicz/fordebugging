<template>
    <section class="bg-gray-50 dark:bg-gray-900">
        <div class="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
            <a class="flex items-center mb-6 text-2xl font-semibold text-gray-900 dark:text-white">
                <img class="w-8 h-8 mr-2" src="/logo-icon.svg" alt="logo">
                Kuba Contracts

            </a>
            <div v-if="errors" class="pb-6 md:space-y-6 w-auto">
                <Alert variant="destructive">
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>
                        Login has failed. Please check Credentials.
                    </AlertDescription>
                </Alert>
            </div>
            <div
                class="w-full bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
                <div class="p-6 space-y-4 md:space-y-6 sm:p-8">
                    <h1 class="text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl dark:text-white">
                        Sign in to your account
                    </h1>
                    <form class="space-y-4 md:space-y-6" @submit.prevent="handleLogin">
                        <FormField>
                            <FormItem>
                                <FormLabel>Email</FormLabel>
                                <FormControl>
                                    <Input type="text" placeholder="Enter Your Email" v-model="form.email" />
                                </FormControl>
                            </FormItem>
                        </FormField>
                        <div>
                            <FormField>
                                <FormItem>
                                    <FormLabel>Password</FormLabel>
                                    <FormControl>
                                        <Input type="password" placeholder="Enter Password" v-model="form.password" />
                                    </FormControl>
                                </FormItem>
                            </FormField>
                        </div>
                        <div class="">

                            <Checkbox id="terms" />
                            <label for="terms"
                                class="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                Remember me?
                            </label>
                        </div>

                        <Button type="submit">Login</Button>

                        <p class="text-sm font-light text-gray-500 dark:text-gray-400">
                            Don’t have an account ? <br><a
                                class="font-medium text-primary-600 hover:underline dark:text-primary-500">Then you are not
                                supposed to be here</a>
                        </p>
                    </form>
                </div>
                <pre>{{ form }}</pre>
                <pre>{{ errors }}</pre>
            </div>
        </div>
    </section>
</template>

<script setup lang="ts">

import {
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage
} from '@/components/ui/form'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
const form = ref({
    email: "",
    password: ""
});

definePageMeta({
    middleware: ["guest"]
});

const auth = useAuthStore();

import {ref} from 'vue';

const errors = ref(false);

async function handleLogin() {
    if (auth.isLoggedIn) return;

    const { error } = await auth.login(form.value);

    if (!error.value) {
        return navigateTo("/dashboard")
    } else if (error.value) {
        errors.value = true;
    }
}
</script>
