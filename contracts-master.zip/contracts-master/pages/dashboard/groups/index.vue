<template>
  <section class="grid gap-5 md:grid-cols-3">
    <Card>
      <CardHeader>
        <CardTitle>Add New Group</CardTitle>
        <CardDescription>Create a new Group</CardDescription>
      </CardHeader>
      <CardFooter>
        <Button class="w-full">Add</Button>
      </CardFooter>
    </Card>
    <div class="flex mt-auto flex-end col-span-2">
      <Input type="text" placeholder="Search Groups..."/>
    </div>
  </section>

  <main>
    <GroupsList />
  </main>
</template>

<script setup lang="ts">
definePageMeta({
  layout: 'dashboard',
  //middleware: ['auth'],
})
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
</script>

