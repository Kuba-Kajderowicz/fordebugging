<template>
  <div class="hidden space-y-6 p-10 pb-16 md:block">
    <div class="space-y-0.5">
      <h2 class="text-2xl font-bold tracking-tight">
        Create new Group
      </h2>
      <p class="text-muted-foreground">
        Manage & Create new groups
      </p>
    </div>
    <Separator class="my-6" />
    <CreateGroup/>
  </div>
</template>

<script lang="ts" setup>
import { Separator } from '@/components/ui/separator'

definePageMeta({
  layout: 'dashboard',
})

</script>
