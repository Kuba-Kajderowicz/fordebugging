<template>
  <!-- Status Cards -->
  <StatusCard />
  <!-- Charts -->
  <SalesChart />
  <!-- New customer list -->
  <NewTrainer />
</template>

<script setup>
  definePageMeta({
    layout: 'dashboard',
  })
  
</script>                                                                                                                                                                                                                        