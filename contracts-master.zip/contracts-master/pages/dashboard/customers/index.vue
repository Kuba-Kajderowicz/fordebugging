<template>
  <div class="container py-10 mx-auto">
    <DataTable :columns="columns" :data="data" />
  </div>
</template>

<script setup lang="ts">
import { columns } from "../../../composables/customers/columns"
import type { Customer } from '../../../composables/customers/columns';
import DataTable from "../../../components/ui/DataTable.vue"

const data = ref<Customer[]>([])


data.value = [{
  id: "728ed52f",
  amount: 100,
  status: "Example Name",
  email: "2@example.com",
  password: "m@example.com",
},
{
  id: "728ed52f",
  amount: 100,
  status: "Example Name",
  email: "m@example.com",
},
{
  id: "728ed52f",
  amount: 100,
  status: "Example Name",
  email: "4@example.com",
  whut: '123'
},
{
  id: "728ed52f",
  amount: 100,
  status: "Example Name",
  email: "m@example.com",
},];

definePageMeta({
  layout: 'dashboard',
 // middleware: ['auth']
}) 
</script>
