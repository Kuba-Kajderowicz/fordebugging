<template>
  <aside class="sticky top-[65px] h-[calc(100vh-65px)] py-5">
    <div
      class="flex h-full w-full flex-col gap-5 overflow-y-auto rounded-md border bg-card pb-5 scrollbar-thin scrollbar-thumb-input scrollbar-thumb-rounded-md">
      <SideBarItem :links="menu" />
      <div class="mt-auto">
        <SideBarItem :links="bottomMenu" />
      </div>
    </div>
  </aside>
</template>

<script lang="ts" setup>
const bottomMenu = [
  {
    title: "Settings",
    icon: "heroicons:cog-8-tooth",
  },
  {
    title: "Help",
    icon: "heroicons:question-mark-circle",
  },
  {
    title: "Logout",
    icon: "heroicons:arrow-left-on-rectangle",
  },
];
const menu = [
  {
    title: "Dashboard",
    icon: "heroicons:home",
    link: "/dashboard",
  },
  {
    title: "Customers",
    icon: "heroicons:users",
    items: [
      { title: "View" , link: '/dashboard/customers/'},
      { title: "Create" },
      { title: "Edit" },
      { title: "Delete" },
      { title: "Details" },
    ],
  },
  {
    title: "Groups",
    icon: "heroicons:user-group",
    items: [
      { title: "View", link: '/dashboard/groups/' },
      { title: "Create", link: '/dashboard/groups/create'},
      { title: "Edit" },
      { title: "Delete" },
      { title: "Details" },
    ],
  },
  {
    title: "Products",
    icon: "heroicons:cube",
    items: [
      { title: "List" },
      { title: "Create" },
      { title: "Edit" },
      { title: "Delete" },
      { title: "Details" },
    ],
  },
  {
    title: "Staff",
    icon: "heroicons:user",
    items: [
      { title: "List" },
      { title: "Create" },
      { title: "Edit" },
      { title: "Delete" },
      { title: "Details" },
    ],
  },
  {
    title: "Analytics",
    icon: "heroicons:chart-pie",
    items: [{ title: "Overview" }, { title: "Statistics" }, { title: "Trends" }],
  },
];
</script>

<style></style>