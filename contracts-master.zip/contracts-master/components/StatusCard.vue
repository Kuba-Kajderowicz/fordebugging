<template>
  <section class="grid gap-5 md:grid-cols-3">
    <!-- Revenue Card -->
    <div class="rounded-lg border bg-card p-6">
      <div class="flex items-center justify-between">
        <p class="text-sm font-medium">Total Clients</p>
        <span class="shrink-0">
          <Icon name="heroicons:user-group" class="w-4 h-4 text-muted-foreground" />
        </span>
      </div>

      <p class="mt-1.5 text-xl font-extrabold">819</p>
      <p class="text-xs text-muted-foreground">20% more than last month</p>
    </div>
    <!-- Sales Card -->

    <div class="rounded-lg border bg-card p-6">
      <div class="flex items-center justify-between">
        <p class="text-sm font-medium">Total Groups</p>
        <span class="shrink-0">
          <Icon name="heroicons:user-group" class="w-4 h-4 text-muted-foreground" />
        </span>
      </div>

      <p class="mt-1.5 text-xl font-extrabold">{{ result }}</p>
      <p class="text-xs text-muted-foreground">??% more than last month</p>
    </div>

    <!-- card -->
    <div class="rounded-lg border bg-card p-6">
      <div class="flex items-center justify-between">
        <p class="text-sm font-medium">Total Revenue</p>
        <span class="shrink-0">
          <Icon name="heroicons:banknotes" class="w-4 h-4 text-muted-foreground" />
        </span>
      </div>

      <p class="mt-1.5 text-xl font-extrabold">$432.30</p>
      <p class="text-xs text-muted-foreground">20% more than last month</p>
    </div>
  </section>
</template>

<script lang="ts" setup>


//data.value = await auth.fetchGroupCount();

</script>