<template>
  <div>
    <form class="space-y-8" @submit.prevent="handleCreateGroup">
      <FormField>
        <FormItem>
          <FormLabel>Group Name</FormLabel>
          <FormControl>
            <Input type="text" placeholder="Enter Group Name" v-model="form.name" />
          </FormControl>
          <FormDescription>
            This will the group name displayed
          </FormDescription>
        </FormItem>
      </FormField>
      <!-- Group Level -->
      <FormField v-slot="{ componentField }" name="level" v-model="form.level">
        <FormItem>
          <FormLabel>Level</FormLabel>

          <Select v-bind="componentField">
            <FormControl>
              <SelectTrigger>
                <SelectValue placeholder="Select a level" />
              </SelectTrigger>
            </FormControl>
            <SelectContent>
              <SelectGroup>
                <SelectItem v-for="level in levels" :key="level" :value="level">
                  {{ level }}
                </SelectItem>
                <SelectItem> None Specified </SelectItem>
              </SelectGroup>
            </SelectContent>
          </Select>
          <FormDescription>
            This will be the specified level for the group
          </FormDescription>
          <FormMessage />
        </FormItem>
      </FormField>
      <!--Min Max Age -->
      <div class="grid gap-6 mb-6 md:grid-cols-2">
        <div>
          <FormField>
            <FormItem>
              <FormLabel>Minimum Age</FormLabel>
              <FormControl>
                <Input type="number" placeholder="Minimum Age" v-model="form.minAge" />
              </FormControl>
              <FormDescription>
                Minimum age for the Attendant
              </FormDescription>
            </FormItem>
          </FormField>
        </div>
        <div>
          <FormField>
            <FormItem>
              <FormLabel>Maximum Age</FormLabel>
              <FormControl>
                <Input type="number" placeholder="Maximum Age" v-model="form.maxAge" />
              </FormControl>
              <FormDescription>
                Maximum age for the Attendant
              </FormDescription>
            </FormItem>
          </FormField>
        </div>
      </div>
      <Button type="submit" size="sm" class="text-xs mt-2">Add Group</Button>
    </form>
    <Toaster />
  </div>
</template>

<script lang="ts" setup>

import { useToast } from '@/components/ui/toast/use-toast'
import Toaster from '@/components/ui/toast/Toaster.vue'

// Import authentication store
const auth = useAuthStore();

const levels = ref(['Beginner', 'Advanced']) // TODO: FETCH FROM API

const { toast } = useToast()

const error = null;

const form = ref({
  name: "",
  level: "",
  minAge: "",
  maxAge: ""
});

function displaySuccessToast(name: string) {
  toast({
    title: 'Group Creation Failed!',
    description: 'Server did not allow server creation. Please review your actions',
    variant: "destructive" 
  });
}

async function handleCreateGroup() {


  const { error } = await auth.createGroup(form.value);

  if (!error.value) {
    navigateTo("/dashboard/groups/");

    // TODO: display success 
  } else {
    displaySuccessToast(form.value.name);
  }
}

</script>

<style></style>