<template>
  <div class="mt-5">
    <Table>
      <TableCaption>All Groups</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead>
            Name
          </TableHead>
          <TableHead>Level</TableHead>
          <TableHead>Category</TableHead>
          <TableHead class="text-right">
            Min Age
          </TableHead>
          <TableHead class="text-right">
            Max Age
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <template v-for="(g, i) in  data " :key="i">
          <TableRow>
            <TableCell class="font-medium">
              {{ g.name.first }}
            </TableCell>
            <TableCell>Beginner</TableCell>
            <TableCell>Acrobatics</TableCell>
            <TableCell class="text-right">
              12
            </TableCell>
            <TableCell class="text-right">
              17
            </TableCell>
          </TableRow>
        </template>
        <TableRow>
          <TableCell class="font-medium">
            Beginner Acrobatics
          </TableCell>
          <TableCell>Beginner</TableCell>
          <TableCell>Acrobatics</TableCell>
          <TableCell class="text-right">
            12
          </TableCell>
          <TableCell class="text-right">
            17
          </TableCell>
        </TableRow>
      </TableBody>
    </Table>
  </div>
  <div class="mt-5">
    <DataTable :columns="columns" :data="groupdata" />
  </div>
  <pre> {{ jsObject  }}</pre>
</template>

<script lang="ts" setup>
import { columns } from "../composables/groups/columns";
import type { Group } from "../composables/groups/columns";
import DataTable from "../components/ui/DataTable.vue"
import { ref } from 'vue'

import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'

const groupdata = ref<Group[]>([])


async function getData(): Promise<Group[]> {
  return [
    {
      id: "728ed52f",
      name: '100',
      level: "pending",
      category: "m@example.com",
      minage: 1,
      maxage: 2,
    }
  ];
}


groupdata.value = [{
  id: "728ed52f",
  name: 'Beginner',
  level: "Beginner",
  category: "Akro",
  minage: 1,
  maxage: 2,
},
{
  id: "728ed52f",
  name: 'Beginner',
  level: "Beginner",
  category: "Akro",
  minage: 1,
  maxage: 2,
},
{
  id: "728ed52f",
  name: 'Beginner',
  level: "Beginner",
  category: "Akro",
  minage: 1,
  maxage: 2,
},
{
  id: "728ed52f",
  name: 'Beginner',
  level: "advanced",
  category: "Akro",
  minage: 1,
  maxage: 2,
},];


</script>
